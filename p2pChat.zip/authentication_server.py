from twisted.internet.protocol import Factory, Protocol
from twisted.internet.endpoints import TCP4ServerEndpoint
from twisted.internet import reactor
from Crypto.Cipher import AES
from user import User
import json, os, hashlib

class AS(Protocol):
    def __init__(self, users):
        self.users = users
        self.name = None
        self.state = "GETNAME"

    def connectionMade(self):
        print("connection made to auth")
        # self.transport.write("What's your name?")

    def connectionLost(self, reason):
        # if self.name in self.users:
        #     del self.users[self.name]
        print("Lost Connection")

    def dataReceived(self, data):
        '''
            expects data in this format
            {
                username: "usrname"
                password: "encrypted_password"
                service: "A"
            }
            and returns
            {
                status: "OK"
                server_auth: "encrypted_password",
                user_shared_key: "shared_key",
                peer_shared_key: "service_shared_key"
            }
        '''

        json_data = json.loads(data)
        print "recieved message: %s" % json_data
        username = json_data['username'].strip()
        requested_username = json_data['service']
        if self.users[username]:
            # import ipdb; ipdb.set_trace()
            user = self.users[username]
            requested_user = self.users[requested_username]
            if self.verify(user, json_data['password']):
                status, server_auth, shared_key, service_shared_key = self.generate_success(user, requested_user)
            else:
                status, server_auth, shared_key, service_shared_key = self.generate_error("Service not found")    # return random strings, confuse the enemy
        else:
            print("we in NOT")
            status, server_auth, shared_key, service_shared_key = self.generate_error("Service not found")# confuse the enemy
        response = json.dumps({
            "status": status,
            "server_auth": server_auth,
            "user_shared_key": shared_key,
            "peer_shared_key": service_shared_key,
            "ttl": 3
        })
        self.transport.write(response)

    def verify(self, user, password):
        plaintext = user.decrypt(password)
        return plaintext == user.password

    def generate_success(self, user, requested_user):
        shared_key = user.generate_shared_key(requested_user)
        print("this is the shared key %s" % shared_key)
        return "OK", user.encrypt("Hello %s" % user.name), user.encrypt(shared_key), requested_user.encrypt(shared_key)

    def generate_error(self, message):
        return message, message, message, message

    # def registerUser(self, data):
    #     json_data = json.loads(data)
    #     self.name = json_data["id"]
    #     response = json.dumps({
    #         'authentication': 'success',
    #         'message': 'Welcome %s' % self.name
    #     })
    #     self.transport.write(response)
    #     self.users[self.name] = self
    #     self.state = "CHAT"

class ASFactory(Factory):
    def __init__(self, users):
        self.users = {
            "bob": users[0],
            "alice": users[1]
        } # maps user names to Chat instances

    def buildProtocol(self, addr):
        return AS(self.users)

# Credentials
ALICE_PRIVATE_KEY = '\xa4Tyf\x82\xd8=@\xce<\xd2\xa3\x88$`\x81\xceM9t\xa3f\x8a3@\xdc\x8c\x9dnj\xe0\xbd'
BOB_PRIVATE_KEY = '\xb7d\xfe\xf7\xf3\x86\x87e\x87\x10@C?\x82\x1e\x982\xc5\x85\x0c\xe4\x02\xd0\x1d<\xf6\xc1\xe0i\nTe'

# Initial vector
IV='\xe7\x97Ao\xeb>-@\\\x89! \xc8\x80\x7f\x83'
# Registering users
alice = User(username="alice", password="alice_pwd", private_key=ALICE_PRIVATE_KEY, IV=IV)
bob = User(username="bob", password="bob_pwd", private_key=BOB_PRIVATE_KEY, IV=IV)

endpoint = TCP4ServerEndpoint(reactor, 3000)
endpoint.listen(ASFactory([bob, alice]))
reactor.run()
